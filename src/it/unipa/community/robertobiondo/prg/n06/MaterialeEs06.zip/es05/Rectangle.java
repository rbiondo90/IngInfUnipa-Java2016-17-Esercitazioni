package it.unipa.community.marcolacascia.prg.n05.es05;

public class Rectangle extends Shape {
	private double w, h;

	public Rectangle(double w, double h){
		setWidht(w);
		setHeight(h);
	}

	public Rectangle(){
		this(2.0, 1.0);
	}

	public double getWidht(){
		return w;
	}

	public double getHeight(){
		return h;
	}

	public void setWidht(double w){
		this.w = w>0.0 ? w : 1.0;
	}

	public void setHeight(double h){
		this.h = h>0.0 ? h : 1.0;
	}

	public double area(){
		return w*h;
	}

	public double perimeter(){
		return 2.0*(w+h);
	}
}