package it.unipa.community.marcolacascia.prg.n05.es05;
public class Square extends Rectangle {
	public Square(double l){
		super(l, l);
	}

	public Square() {
		this(1.0);
	}

	public void setWidht(double w){
		super.setWidht(w);
		super.setHeight(w);
	}

	public void setHeight(double h){
		super.setWidht(h);
		super.setHeight(h);
	}

}