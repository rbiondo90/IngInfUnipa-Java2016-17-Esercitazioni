package it.unipa.community.marcolacascia.prg.n05.es05;

public class Main{
	public static void main(String args[]) {

		Circle c = new Circle();
		c.setRadius(1.0);
		System.out.println(c.area());
		System.out.println(c.perimeter());
		System.out.println(c.getColor());
		System.out.println(c.getFilled());


		Rectangle r = new Rectangle();
		r.setWidht(2.0);
		r.setHeight(4.0);
		System.out.println(r.area());
		System.out.println(r.perimeter());

		Square s = new Square();
		s.setHeight(5.0);
		System.out.println(s.area());
		System.out.println(s.perimeter());

		s.setWidht(6.0);
		System.out.println(s.area());
		System.out.println(s.perimeter());


	}
}