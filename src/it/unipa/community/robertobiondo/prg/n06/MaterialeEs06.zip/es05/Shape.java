package it.unipa.community.marcolacascia.prg.n05.es05;

public abstract class Shape {
	private String color;
	private boolean filled;

	public abstract double area();
	public abstract double perimeter();

	public Shape(){
		setColor("red");
		setFilled(true);
	}

	public String getColor(){
		return color;
	}

	public boolean getFilled(){
		return filled;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setFilled(boolean filled){
		this.filled = filled;
	}
}